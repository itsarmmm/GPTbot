import os, re
import logging
from aiogram import Bot, Dispatcher, types, executor
from aiogram.types.message import ContentType
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import openai
import asyncio
from connect import SQLighter
import keyboards as kb
import speech_recognition as sr
from pydub import AudioSegment
import urllib.request


db = SQLighter('db.sqlite3')

r = sr.Recognizer()

openai.api_key = 'sk-gpt-bot-SEWTNzr9PB8N6lyBEpPOT3BlbkFJgRCY1WvZj4QQhjrOFXmk'

if not os.path.exists("users"):
    os.mkdir("users")

NUMBERS_ROWS = 6

YOOTOKEN = "" \
           ""

logging.basicConfig(level=logging.INFO)
bot = Bot(token='5322808437:AAG4ynYkTAvCmzTjG5ONJSFyq2uijOd5vNE')
dp = Dispatcher(bot)



#AUDIO CONVERT ogg2wav
def ogg2wav(ofn):
    wfn = ofn.replace('.ogg','.wav')
    x = AudioSegment.from_file(ofn)
    x.export(wfn, format='wav')


#REGULAR BOT
@dp.callback_query_handler(lambda c: c.data == 'check')
async def check(callback_query: types.CallbackQuery):
    channels_kb = InlineKeyboardMarkup(row_width=1)

    channel1 = InlineKeyboardButton('Подписаться', url=f'https://t.me/{db.get_channel()[1:]}')
    check = InlineKeyboardButton('Я подписался', callback_data='check')

    channels_kb.add(channel1, check)

    try:
        user_channel_status = await bot.get_chat_member(db.get_channel(), user_id=callback_query.message.chat.id)
        user_channel_status = re.findall(r"\w*", str(user_channel_status))

        if 'member' or 'administrator' or 'creator' not in user_channel_status:
            await bot.send_message(callback_query.message.chat.id, "Похоже вы не подписались на канал): Подпишитесь на канал, после подписки нажмите кнопку я подписался.", reply_markup=channels_kb)
            return
    except:
        pass


    await bot.send_message(callback_query.message.chat.id, """🤖 Привет, .! Я бот ChatGPT!

 Вы можете задавать любые вопросы, но с ограничением в 10 вопросов на день. Счет обновляется раз в сутки.

 Также бот иногда может грузить ответ в течении нескольких минут. Все зависит от серверов на стороне OpenAI!

 Советы к правильному использованию:
 – Задавайте осмысленные вопросы, расписывайте детальнее.
 – Не пишите ерунду иначе одержите её же в ответ.

 Примеры вопросов/запросов:
 ~ Сколько будет 7 * 8?
 ~ Когда началась Вторая Мировая?
 ~ Напиши код калькулятора на Python
 ~ Напиши сочинение как я провел лето
""", reply_markup=kb.main_keyboard)


@dp.message_handler(commands=['start'])
async def start_command(message: types.Message):
    if not db.user_exists(message.from_user.id):
        db.add_user(message.from_user.id, message.from_user.username)
        try:
            referrer = message.text.split(' ')[1]
            db.update_days(referrer, 3)
            await bot.send_message(referrer, 'Вы получили +3 бесплатного вопроса за приглашённого пользователя!🤩')

        except Exception as e:
            pass

    db.set_image(message.from_user.id, image=0)
    channels_kb = InlineKeyboardMarkup(row_width=1)

    channel1 = InlineKeyboardButton('Подписаться', url=f'https://t.me/{db.get_channel()[1:]}')
    check = InlineKeyboardButton('Я подписался', callback_data='check')

    channels_kb.add(channel1, check)

    try:
        user_channel_status = await bot.get_chat_member(db.get_channel(), user_id=message.from_user.id)
        user_channel_status = re.findall(r"\w*", str(user_channel_status))

        if 'member' or 'administrator' or 'creator' not in user_channel_status:
            await bot.send_message(message.from_user.id,
                                   "Похоже вы не подписались на канал): Подпишитесь на канал, после подписки нажмите кнопку я подписался.",
                                   reply_markup=channels_kb)
            return
    except:
        pass

    await message.answer(text="""🤖 Привет! Я бот ChatGPT!

 Вы можете задавать любые вопросы, но с ограничением в 10 вопросов на день. Счет обновляется раз в сутки.

 Также бот иногда может грузить ответ в течении нескольких минут. Все зависит от серверов на стороне OpenAI!

 Советы к правильному использованию:
 – Задавайте осмысленные вопросы, расписывайте детальнее.
 – Не пишите ерунду иначе одержите её же в ответ.

 Примеры вопросов/запросов:
 ~ Сколько будет 7 * 8?
 ~ Когда началась Вторая Мировая?
 ~ Напиши код калькулятора на Python
 ~ Напиши сочинение как я провел лето
""", reply_markup=kb.main_keyboard)



@dp.message_handler(lambda message: message.text == "Безлимитный доступ🔰")
async def unlimited_access(message: types.Message):
    await bot.send_invoice(message.from_user.id, title="Безлимитный доступ", description=" ",
                           payload="deposit", provider_token=YOOTOKEN,
                           currency="RUB", start_parameter="test_bot",
                           prices=[{"label": "Руб.", "amount": 50000}])


@dp.pre_checkout_query_handler()
async def process_pre_checkout_query(pre_checkout_query: types.PreCheckoutQuery):
    await bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True)



@dp.message_handler(content_types=ContentType.SUCCESSFUL_PAYMENT)
async def process_pay(message: types.Message):

    await message.answer(f"""Вы покупали *Безлимитный доступ* бота. Наслаждайтесь!""", parse_mode="Markdown")



@dp.message_handler(lambda message: message.text == "Настройки роли😜")
async def settings(message: types.Message):
    check_emoji = " "

    roles_kb = InlineKeyboardMarkup(row_width=1)

    if db.get_role(message.from_user.id) == "assistant":
        check_emoji = "✅"
    assistant = InlineKeyboardButton(f'Ассистент👩🏻‍💼 {check_emoji}', callback_data='assistant')

    check_emoji = " "
    if db.get_role(message.from_user.id) == "english_teacher":
        check_emoji = "✅"
    english_teacher = InlineKeyboardButton(f'Учитель английского👩🏻‍🏫 {check_emoji}', callback_data='english_teacher')

    check_emoji = " "
    if db.get_role(message.from_user.id) == "psycho":
        check_emoji = "✅"
    psycho = InlineKeyboardButton(f'Психолог👩🏼‍⚕️ {check_emoji}', callback_data='psycho')

    check_emoji = " "
    if db.get_role(message.from_user.id) == "programmer":
        check_emoji = "✅"
    programmer = InlineKeyboardButton(f'Разработчик👨🏻‍💻 {check_emoji}', callback_data='programmer')

    check_emoji = " "
    if db.get_role(message.from_user.id) == "elon":
        check_emoji = "✅"
    elon = InlineKeyboardButton(f'Илон Маск⚡️ {check_emoji}', callback_data='elon')

    check_emoji = " "
    if db.get_role(message.from_user.id) == "rick":
        check_emoji = "✅"
    rick = InlineKeyboardButton(f'Рик Санчез👨🏼‍⚕️ {check_emoji}', callback_data='elon')


    roles_kb.add(assistant, english_teacher, psycho, programmer, elon, rick)

    await message.answer(text=f"""*Настройки*⚙

Здесь вы можете настроить стиль диалога нейросети. Просто выбирайте вариант и напишите вопрос""", parse_mode="Markdown", reply_markup=roles_kb)


@dp.callback_query_handler(lambda c: len(c.data) > 2)
async def deposit_callback(callback_query: types.CallbackQuery):
    db.set_role(callback_query.message.chat.id, callback_query.data)

    check_emoji = " "

    rolesUPD_kb = InlineKeyboardMarkup(row_width=1)

    if db.get_role(callback_query.message.chat.id) == "assistant":
        check_emoji = "✅"
    assistant = InlineKeyboardButton(f'Ассистент👩🏻‍💼 {check_emoji}', callback_data='assistant')

    check_emoji = " "
    if db.get_role(callback_query.message.chat.id) == "english_teacher":
        check_emoji = "✅"
    english_teacher = InlineKeyboardButton(f'Учитель английского👩🏻‍🏫 {check_emoji}', callback_data='english_teacher')

    check_emoji = " "
    if db.get_role(callback_query.message.chat.id) == "psycho":
        check_emoji = "✅"
    psycho = InlineKeyboardButton(f'Психолог👩🏼‍⚕️ {check_emoji}', callback_data='psycho')

    check_emoji = " "
    if db.get_role(callback_query.message.chat.id) == "programmer":
        check_emoji = "✅"
    programmer = InlineKeyboardButton(f'Разработчик👨🏻‍💻 {check_emoji}', callback_data='programmer')

    check_emoji = " "
    if db.get_role(callback_query.message.chat.id) == "elon":
        check_emoji = "✅"
    elon = InlineKeyboardButton(f'Илон Маск⚡️ {check_emoji}', callback_data='elon')

    check_emoji = " "
    if db.get_role(callback_query.message.chat.id) == "rick":
        check_emoji = "✅"
    rick = InlineKeyboardButton(f'Рик Санчез👨🏼‍⚕️ {check_emoji}', callback_data='rick')

    rolesUPD_kb.add(assistant, english_teacher, psycho, programmer, elon, rick)

    await callback_query.message.edit_reply_markup(reply_markup=rolesUPD_kb)


@dp.message_handler(lambda message: message.text == "Сбросить контекст🔄")
async def clear(message: types.Message):
    with open(f'users/{message.chat.id}.txt', 'w', encoding='utf-8') as file:
        file.write('')

    return await bot.send_message(chat_id=message.chat.id, text='История очищена!')

@dp.message_handler(lambda message: message.text == "Профиль💸")
async def profile(message: types.Message):
    await message.answer(text = f"""*Профиль*💸

🕰 Дневной лимит:
     💭 - 20/{db.get_questions(message.from_user.id)}
📤 Приглашено: 0

Ваша реферальная ссылка `https://t.me/AI_Help_me23_Bot?start={message.from_user.id}`

За каждого друга вы получаете +3 запроса к вашему дневному лимиту!""", parse_mode="Markdown")


@dp.message_handler(lambda message: message.text == "Генерация фото🔮")
async def profile(message: types.Message):
    channels_kb = InlineKeyboardMarkup(row_width=1)

    channel1 = InlineKeyboardButton('Подписаться', url=f'https://t.me/{db.get_channel()[1:]}')
    check = InlineKeyboardButton('Я подписался', callback_data='check')

    channels_kb.add(channel1, check)

    try:
        user_channel_status = await bot.get_chat_member(db.get_channel(), user_id=message.from_user.id)
        user_channel_status = re.findall(r"\w*", str(user_channel_status))

        if 'member' or 'administrator' or 'creator' not in user_channel_status:
            await bot.send_message(message.from_user.id,
                                   "Похоже вы не подписались на канал): Подпишитесь на канал, после подписки нажмите кнопку я подписался.",
                                   reply_markup=channels_kb)
            return
    except:
        pass

    await message.answer(text="Отправьте ваш запрос и я сгенерирую изображение!", parse_mode="Markdown")
    db.set_image(message.from_user.id)



@dp.message_handler()
async def handle_message(message: types.Message):
    channels_kb = InlineKeyboardMarkup(row_width=1)

    channel1 = InlineKeyboardButton('Подписаться', url=f'https://t.me/{db.get_channel()[1:]}')
    check = InlineKeyboardButton('Я подписался', callback_data='check')

    channels_kb.add(channel1, check)

    try:
        user_channel_status = await bot.get_chat_member(db.get_channel(), user_id=message.from_user.id)
        user_channel_status = re.findall(r"\w*", str(user_channel_status))

        if 'member' or 'administrator' or 'creator' not in user_channel_status:
            await bot.send_message(message.from_user.id,
                                   "Похоже вы не подписались на канал): Подпишитесь на канал, после подписки нажмите кнопку я подписался.",
                                   reply_markup=channels_kb)
            return
    except:
        pass

    if int(db.get_questions(message.chat.id)) == 0:
        await message.answer('Вы исчерпали лимит бесплатных запросов! Покупайте безлимитный режим чтобы продолжить использовать бота')
        return


    if int(db.get_image(message.from_user.id)) == 1:
        await bot.send_message(chat_id=message.chat.id, text='Обрабатываю запрос, пожалуйста подождите!')
        response = openai.Image.create(
            prompt=message.text,
            n=1,
            size="1024x1024"
        )
        image_url = response['data'][0]['url']
        filename = f"images/{message.from_user.id}.png"

        urllib.request.urlretrieve(image_url, filename)

        await bot.send_photo(message.from_user.id, open(filename, 'rb'))
        db.set_image(message.from_user.id, image=0)
        return


    if f"{message.chat.id}.txt" not in os.listdir('users'):
        with open(f"users/{message.chat.id}.txt", "x") as f:
            f.write('')

    with open(f'users/{message.chat.id}.txt', 'r', encoding='utf-8') as file:
        oldmes = file.read()

    if message.text == '/clear':
        with open(f'users/{message.chat.id}.txt', 'w', encoding='utf-8') as file:
            file.write('')
        return await bot.send_message(chat_id=message.chat.id, text='История очищена!')

    start_prompt = ""

    if db.get_role(message.from_user.id) == "english_teacher":
        start_prompt = """Ты учитель английского языка. Вы действуете, отвечаете и отвечаете, как учитель английского языка. Вы используете тон, манеру и словарный запас
                        учителя английского языка. Никаких пояснений не пишите"""
    if db.get_role(message.from_user.id) == "psycho":
        start_prompt = """Ты психолог. Вы действуете, отвечаете и отвечаете, как психолог. Вы используете тон, манеру и словарный запас
                        психолога. Никаких пояснений не пишите"""
    if db.get_role(message.from_user.id) == "programmer":
        start_prompt = """Ты программист. Вы действуете, отвечаете и отвечаете, как программист. Вы используете тон, манеру и словарный запас
                        программиста. Никаких пояснений не пишите"""
    if db.get_role(message.from_user.id) == "elon":
        start_prompt = """Ты Илон Маск. Вы действуете, отвечаете и отвечаете, как Илон Маск. Вы используете тон, манеру и словарный запас
                        Илон Маск использовал бы. Никаких пояснений не пишите. Только отвечай как Илон Маск. Вы должны знать все
                        знание Илона Маска"""
    if db.get_role(message.from_user.id) == "rick":
        start_prompt = """Ты Рик Санчез. Вы действуете, отвечаете и отвечаете, как Рик Санчез. Вы используете тон, манеру и словарный запас
                        Рик Санчез использовал бы. Никаких пояснений не пишите. Только отвечай как Рик Санчез. Вы должны знать все
                        знание Рика Санчеза"""



    try:
        my_message = await bot.send_message(chat_id=message.chat.id, text='Обрабатываю запрос, пожалуйста подождите!')
        completion = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-0301",
            messages=[{"role": "user", "content": oldmes},
                      {"role": "user", "content": f'Предыдущие сообщения: {oldmes}; Запрос: {start_prompt} {message.text}'}],
            presence_penalty=0.6)

        full_text = completion.choices[0].message["content"]
        seperated = full_text.split(' ')
        if len(seperated) <= 10:
            await bot.edit_message_text(text=full_text, chat_id=message.chat.id,
                                  message_id=my_message.message_id)
        else:
            i = 5

            while i<=len(seperated):
                text = ''.join(seperated[j] + ' ' for j in range(i))
                await bot.edit_message_text(text=text, chat_id=message.chat.id,
                                            message_id=my_message.message_id)
                i += 5
                await asyncio.sleep(0.3)

        with open(f'users/{message.chat.id}.txt', 'a+', encoding='utf-8') as file:
            file.write(message.text.replace('\n', ' ') + '\n' + completion.choices[0].message["content"].replace('\n',
                                                                                                                 ' ') + '\n')

        with open(f'users/{message.chat.id}.txt', 'r', encoding='utf-8') as f:
            lines = f.readlines()

        if len(lines) >= NUMBERS_ROWS + 1:
            with open(f'users/{message.chat.id}.txt', 'w', encoding='utf-8') as f:
                f.writelines(lines[2:])

    except Exception as e:
        await bot.send_message(chat_id=message.chat.id, text=e)



@dp.message_handler(content_types=['voice', 'file'])
async def voice_processing(message):
    file_info = await bot.get_file(message.voice.file_id)
    downloaded_file = await bot.download_file(file_info.file_path)
    with open(f'users/{message.chat.id}.ogg', 'wb') as new_file:
        new_file.write(downloaded_file.getvalue())

    sound = AudioSegment.from_ogg(f'users/{message.chat.id}.ogg')
    sound.export(f'users/{message.chat.id}.wav', format="wav")

    filename = f'users/{message.chat.id}.wav'
    with sr.AudioFile(filename) as source:
        # listen for the data (load audio to memory)
        audio_data = r.record(source)
        # recognize (convert from speech to text)
        text = r.recognize_google(language='ru-RU', audio_data=audio_data)

    os.remove(f'users/{message.chat.id}.ogg')
    os.remove(f'users/{message.chat.id}.wav')
    if f"{message.chat.id}.txt" not in os.listdir('users'):
        with open(f"users/{message.chat.id}.txt", "x") as f:
            f.write('')

    with open(f'users/{message.chat.id}.txt', 'r', encoding='utf-8') as file:
        oldmes = file.read()

    if message.text == '/clear':
        with open(f'users/{message.chat.id}.txt', 'w', encoding='utf-8') as file:
            file.write('')
        return await bot.send_message(chat_id=message.chat.id, text='История очищена!')

    start_prompt = ""

    if db.get_role(message.from_user.id) == "english_teacher":
        start_prompt = "Ты учитель английского языка. Пожалуйста помоги мне с этим."
    if db.get_role(message.from_user.id) == "psycho":
        start_prompt = "Представь себя в роле психолога, пожалуйста помоги мне с моей проблемой."
    if db.get_role(message.from_user.id) == "elon":
        start_prompt = "Ты Илона Маск, пожалуйста помоги мне с моей проблемой."
    if db.get_role(message.from_user.id) == "rick":
        start_prompt = "Представь себя в роле Рики Санчез, пожалуйста помоги мне с моей проблемой."
    if db.get_role(message.from_user.id) == "programmer":
        start_prompt = "Ты программист, разработчик программного обеспечения, пожалуйста помоги мне."




    try:
        my_message = await bot.send_message(chat_id=message.chat.id, text='Обрабатываю запрос, пожалуйста подождите!')
        completion = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-0301",
            messages=[{"role": "user", "content": oldmes},
                      {"role": "user", "content": f'Предыдущие сообщения: {oldmes}; Запрос: {start_prompt} {text}'}],
            presence_penalty=0.6)

        await bot.edit_message_text(text=completion.choices[0].message["content"], chat_id=message.chat.id,
                              message_id=my_message.message_id)

        with open(f'users/{message.chat.id}.txt', 'a+', encoding='utf-8') as file:
            file.write(message.text.replace('\n', ' ') + '\n' + completion.choices[0].message["content"].replace('\n',
                                                                                                                 ' ') + '\n')

        with open(f'users/{message.chat.id}.txt', 'r', encoding='utf-8') as f:
            lines = f.readlines()

        if len(lines) >= NUMBERS_ROWS + 1:
            with open(f'users/{message.chat.id}.txt', 'w', encoding='utf-8') as f:
                f.writelines(lines[2:])

    except Exception as e:
        pass



if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
