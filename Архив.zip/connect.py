import sqlite3

class SQLighter:
    def __init__(self, database):
        # Connecting to database
        self.connection = sqlite3.connect(database)
        self.cursor = self.connection.cursor()


    def get_users(self):
        with self.connection:
            res = self.cursor.execute('SELECT `user_id` FROM `users`').fetchall()
            users = []
            for i in range(len(res)):
                users.append(res[i][0])
            return users


    def user_exists(self, user_id):
        with self.connection:
            result = self.cursor.execute('SELECT * FROM `main_users` WHERE `user_id` = ?', (user_id,)).fetchall()
            return bool(len(result))


    def add_user(self, user_id, username, questions = 20, role = 'assistant', model = 'gpt-3.5-turbo-0301'):
        with self.connection:
            return self.cursor.execute("INSERT INTO `main_users` (`user_id`,`username`, `questions`, `role`, `model`) VALUES(?,?,?,?,?)", (user_id, username, questions, role, model))


    def get_questions(self, user_id):
        with self.connection:
            return self.cursor.execute("SELECT `questions` FROM `main_users` WHERE `user_id` = ?", (user_id,)).fetchone()[0]


    def update_questions(self, user_id, amount = -1):
        with self.connection:
            current_questions = self.cursor.execute('SELECT `questions` FROM `main_users` WHERE `user_id` = ? LIMIT 1', (user_id,)).fetchone()[0]
            new_questions = int(current_questions) + amount
            return self.cursor.execute("UPDATE `main_users` SET `questions` = ? WHERE `user_id` = ?", (new_questions, user_id))

    def get_channel(self):
        with self.connection:
            return self.cursor.execute("SELECT `channel` FROM `channel` WHERE `id` = ?", (1,)).fetchone()[0]

    def get_role(self, user_id):
        with self.connection:
            return self.cursor.execute("SELECT `role` FROM `main_users` WHERE `user_id` = ?", (user_id,)).fetchone()[0]

    def set_role(self, user_id, role):
        with self.connection:
            return self.cursor.execute("UPDATE `main_users` SET `role` = ? WHERE `user_id` = ?", (role, user_id))

    def set_image(self, user_id, image=1):
        with self.connection:
            return self.cursor.execute("UPDATE `main_users` SET `image` = ? WHERE `user_id` = ?", (image, user_id))

    def get_image(self, user_id):
        with self.connection:
            return self.cursor.execute("SELECT `image` FROM `main_users` WHERE `user_id` = ?", (user_id,)).fetchone()[0]