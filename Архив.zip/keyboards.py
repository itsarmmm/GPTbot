from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

main_keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
button1 = KeyboardButton('Профиль💸')
button2 = KeyboardButton('Генерация фото🔮')
button3 = KeyboardButton('Сбросить контекст🔄')
button4 = KeyboardButton('Настройки роли😜')
button5 = KeyboardButton('Безлимитный доступ🔰')
button6 = KeyboardButton('Настройки⚙️')


main_keyboard.add(button1, button2, button3, button4, button5)