from django.contrib import admin
from . models import Users, Newsletter

# Register your models here.
admin.site.register(Users)
admin.site.register(Newsletter)