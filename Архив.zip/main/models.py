from django.db import models
import json
import requests

# Create your models here.

TOKEN = "5322808437:AAG4ynYkTAvCmzTjG5ONJSFyq2uijOd5vNE"

class Users(models.Model):
    user_id = models.CharField(max_length=200, null=True, blank=True, verbose_name='User ID')
    username = models.CharField(max_length=200, null=True, blank=True, verbose_name='Имя пользователя')
    questions = models.IntegerField(null=True, blank=True, verbose_name='Количество вопросов')
    role = models.CharField(max_length=200, null=True, blank=True, verbose_name='Роль')
    image = models.IntegerField(null=True, blank=True, verbose_name='Изображение')
    model = models.CharField(max_length=200, null=True, blank=True, verbose_name='Модель gpt')
    tariff = models.CharField(max_length=200, null=True, blank=True, verbose_name='Тариф')

    class Meta:
        verbose_name = 'Пользователи'
        verbose_name_plural = 'Пользователи'

    def __str__(self):
        return str(self.username)

class Newsletter(models.Model):
    text = models.TextField(max_length=3000, null=True, blank=True, verbose_name='Текст рассылки')

    class Meta:
        verbose_name = 'Рассылка'
        verbose_name_plural = 'Рассылка'

    def save(self, *args, **kwargs):
        users = Users.objects.all()
        for user in users:
            try:
                data = {'chat_id': user.user_id, 'text': self.text}
                requests.post(url="https://api.telegram.org/bot" + TOKEN + "/sendMessage", data=data).json()
            except Exception as e:
                print(e)
